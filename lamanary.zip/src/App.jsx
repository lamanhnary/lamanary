
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { motion } from "framer-motion";

const vocabData = [
  {
    word: "abundant",
    ipa: "/əˈbʌn.dənt/",
    meaning: "nhiều, phong phú",
    example: "The forest is abundant with wildlife.",
    image: "https://source.unsplash.com/featured/?forest",
    blank: "The forest is ____ with wildlife.",
    extraExercise: {
      question: "Viết lại câu trên bằng tiếng Việt, giữ nguyên từ 'abundant'",
      placeholder: "Nhập câu trả lời..."
    },
    answer: "abundant",
  },
  {
    word: "efficient",
    ipa: "/ɪˈfɪʃ.ənt/",
    meaning: "hiệu quả",
    example: "She is very efficient at her job.",
    image: "https://source.unsplash.com/featured/?office",
    blank: "She is very ____ at her job.",
    extraExercise: {
      question: "Dịch câu sau sang tiếng Việt: 'She is very efficient at her job.'",
      placeholder: "Nhập câu trả lời..."
    },
    answer: "efficient",
  },
];

export default function App() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [userInput, setUserInput] = useState("");
  const [extraInput, setExtraInput] = useState("");
  const [feedback, setFeedback] = useState("");

  const current = vocabData[currentIndex];

  const checkAnswer = () => {
    if (userInput.trim().toLowerCase() === current.answer.toLowerCase()) {
      setFeedback("✅ Chính xác!");
    } else {
      setFeedback(`❌ Sai rồi. Đáp án đúng là: "${current.answer}"`);
    }
  };

  const nextWord = () => {
    setUserInput("");
    setExtraInput("");
    setFeedback("");
    setCurrentIndex((prev) => (prev + 1) % vocabData.length);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-pink-100 to-purple-200 p-4 flex flex-col items-center">
      <motion.h1 
        className="text-3xl font-bold text-purple-800 mb-6"
        initial={{ opacity: 0, y: -20 }} 
        animate={{ opacity: 1, y: 0 }} 
        transition={{ duration: 0.5 }}
      >
        LAMANARY ✨
      </motion.h1>

      <Card className="w-full max-w-md bg-white shadow-lg rounded-2xl">
        <CardContent className="p-4">
          <img src={current.image} alt={current.word} className="rounded-xl mb-3 w-full h-48 object-cover" />
          <h2 className="text-xl font-semibold text-pink-700">{current.word}</h2>
          <p className="text-gray-500 italic">{current.ipa}</p>
          <p className="text-gray-700">💡 {current.meaning}</p>
          <p className="text-sm mt-2">Ví dụ: {current.example}</p>

          <div className="mt-4">
            <p className="mb-1">📝 Điền từ vào chỗ trống:</p>
            <p className="bg-gray-100 p-2 rounded">{current.blank}</p>
            <Input 
              className="mt-2" 
              value={userInput} 
              onChange={(e) => setUserInput(e.target.value)} 
              placeholder="Điền từ vào đây..."
            />
            <Button className="mt-2 w-full bg-purple-500 hover:bg-purple-600" onClick={checkAnswer}>
              Kiểm tra
            </Button>
            {feedback && <p className="mt-2 font-medium text-center">{feedback}</p>}
          </div>

          <div className="mt-6">
            <p className="mb-1">✍️ Bài tập thêm:</p>
            <p className="bg-yellow-50 p-2 rounded border border-yellow-200">{current.extraExercise.question}</p>
            <Input 
              className="mt-2" 
              value={extraInput} 
              onChange={(e) => setExtraInput(e.target.value)} 
              placeholder={current.extraExercise.placeholder} 
            />
          </div>

          <Button 
            className="mt-6 w-full bg-pink-400 hover:bg-pink-500" 
            onClick={nextWord}
          >
            👉 Từ tiếp theo
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
